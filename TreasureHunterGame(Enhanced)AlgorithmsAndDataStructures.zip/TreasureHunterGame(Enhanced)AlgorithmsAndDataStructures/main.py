# ModuleSixMilestone.py(updated)
# Author: Sharadiya Sarkar


# A dictionary for the dragon text game
# The dictionary links a room to other rooms and contains items and villain location
rooms = {
    'Great Hall': {'South': 'Bedroom', 'North': 'Kitchen', 'East': 'Library', 'West': 'Garden'},
    'Bedroom': {'North': 'Great Hall', 'East': 'Cellar', 'item': 'Magic Sword'},
    'Cellar': {'West': 'Bedroom', 'item': 'Shield'},
    'Kitchen': {'South': 'Great Hall', 'item': 'Health Potion'},
    'Library': {'West': 'Great Hall', 'item': 'Spell Book'},
    'Garden': {'East': 'Great Hall', 'item': 'Golden Key'},
    'Dragon Lair': {'South': 'Great Hall', 'villain': 'Dragon'}
}

# Update the Great Hall to include the Dragon Lair as a possible destination
rooms['Great Hall']['North'] = 'Dragon Lair'


def display_current_room(current_room):
    """
    Display the current room to the player
    Args:
        current_room (str): The name of the current room
    """
    print(f"\nYou are in the {current_room}")


def get_valid_directions(current_room):
    """
    Get list of valid directions from current room
    Args:
        current_room (str): The name of the current room
    Returns:
        list: List of valid directions from current room
    """
    if current_room in rooms:
        # Return only direction keys, not items or villain
        return [key for key in rooms[current_room].keys()
                if key not in ['item', 'villain']]
    return []


def display_available_moves(current_room):
    """
    Display available moves to the player
    Args:
        current_room (str): The name of the current room
    """
    valid_directions = get_valid_directions(current_room)
    if valid_directions:
        print(f"You can go: {', '.join(valid_directions)}")
    else:
        print("No exits available from this room.")


def display_room_item(current_room):
    """
    Display item in current room if present
    Args:
        current_room (str): The name of the current room
    """
    if current_room in rooms and 'item' in rooms[current_room]:
        item = rooms[current_room]['item']
        print(f"You see a {item} in the room.")


def display_inventory(inventory):
    """
    Display player's current inventory
    Args:
        inventory (list): List of items player has collected
    """
    if inventory:
        print(f"Inventory: {', '.join(inventory)}")
    else:
        print("Inventory: Empty")


def get_item_command(command, current_room, inventory):
    """
    Process get item command
    Args:
        command (str): Player's get command
        current_room (str): Current room name
        inventory (list): Player's inventory
    Returns:
        bool: True if item was collected, False otherwise
    """
    if current_room in rooms and 'item' in rooms[current_room]:
        item = rooms[current_room]['item']
        # Check if command matches the item (case insensitive)
        if command.lower() == f"get {item.lower()}" or command.lower() == f"take {item.lower()}":
            if item not in inventory:
                inventory.append(item)
                print(f"\nYou picked up the {item}!")
                # Remove item from room after collection
                del rooms[current_room]['item']
                return True
            else:
                print(f"\nYou already have the {item}.")
                return False
        else:
            print(f"\nThere is no '{command.replace('get ', '').replace('take ', '')}' here.")
            print(f"You can get: {item}")
            return False
    else:
        print(f"\nThere are no items to collect in the {current_room}.")
        return False


def process_move_command(command, current_room):
    """
    Process a movement command and return new room
    Args:
        command (str): Player's movement command
        current_room (str): Current room name
    Returns:
        str: New room name or current room if invalid move
    """
    # Extract direction from command (remove 'go ' if present)
    if command.lower().startswith('go '):
        direction = command[3:].strip().title()  # Remove 'go ' and capitalize
    else:
        direction = command.strip().title()  # Just capitalize the direction

    # Check if the direction is valid from current room
    if current_room in rooms and direction in rooms[current_room]:
        new_room = rooms[current_room][direction]
        print(f"\nYou move {direction} to the {new_room}.")
        return new_room
    else:
        # Invalid move - display error and available options
        print(f"\nInvalid move! You cannot go {direction} from the {current_room}.")
        display_available_moves(current_room)
        return current_room


def check_win_condition(inventory, total_items):
    """
    Check if player has collected all items (win condition)
    Args:
        inventory (list): Player's inventory
        total_items (int): Total number of items in game
    Returns:
        bool: True if player has all items, False otherwise
    """
    return len(inventory) == total_items


def check_lose_condition(current_room, inventory, total_items):
    """
    Check if player encountered villain without all items (lose condition)
    Args:
        current_room (str): Current room name
        inventory (list): Player's inventory
        total_items (int): Total number of items in game
    Returns:
        bool: True if player lost, False otherwise
    """
    if current_room in rooms and 'villain' in rooms[current_room]:
        return len(inventory) < total_items
    return False


def count_total_items():
    """
    Count total number of items in the game
    Returns:
        int: Total number of items
    """
    item_count = 0
    for room_data in rooms.values():
        if 'item' in room_data:
            item_count += 1
    return item_count


def main():
    """
    Main game loop function
    """
    # Initialize starting room and inventory
    current_room = 'Great Hall'
    inventory = []
    total_items = count_total_items()

    # Welcome message
    print("=" * 50)
    print("Welcome to the Dragon Text Adventure Game!")
    print("=" * 50)
    print("Your goal: Collect all items before facing the Dragon!")
    print(f"Total items to collect: {total_items}")
    print("=" * 50)
    print("Commands:")
    print("- To move: enter a direction (North, South, East, West)")
    print("- To move: enter 'go' followed by direction (go North)")
    print("- To get item: enter 'get' followed by item name (get Magic Sword)")
    print("- To get item: enter 'take' followed by item name (take Shield)")
    print("=" * 50)

    # Main gameplay loop - continues until win or lose
    game_over = False
    while not game_over:
        # Display current room, available moves, items, and inventory
        display_current_room(current_room)
        display_available_moves(current_room)
        display_room_item(current_room)
        display_inventory(inventory)

        # Check win condition (player has all items and is in Dragon Lair)
        if (current_room == 'Dragon Lair' and
                check_win_condition(inventory, total_items)):
            print("\n" + "=" * 60)
            print("Congratulations! You have collected all items and defeated the dragon!")
            print("Thanks for playing the game. Hope you enjoyed it.")
            print("=" * 60)
            game_over = True
            break

        # Check lose condition (player encounters dragon without all items)
        if check_lose_condition(current_room, inventory, total_items):
            print("\n" + "=" * 40)
            print("NOM NOM...GAME OVER!")
            print("Thanks for playing the game. Hope you enjoyed it.")
            print("=" * 40)
            game_over = True
            break

        # Get player input
        print("\nWhat would you like to do?")
        player_command = input("> ").strip()

        # Input validation - check for empty input
        if not player_command:
            print("\nPlease enter a command!")
            continue

        # Decision branching for different commands
        if (player_command.lower().startswith('go ') or
                player_command.lower() in ['north', 'south', 'east', 'west']):
            # Player wants to move
            current_room = process_move_command(player_command, current_room)

        elif (player_command.lower().startswith('get ') or
              player_command.lower().startswith('take ')):
            # Player wants to get an item
            get_item_command(player_command, current_room, inventory)

        else:
            # Invalid command - provide helpful error message
            print(f"\nInvalid command: '{player_command}'")
            print("Valid commands are:")
            print("- Direction names: North, South, East, West")
            print("- Move commands: go North, go South, etc.")
            print("- Item commands: get [item name], take [item name]")


# Run the game when script is executed directly
if __name__ == "__main__":
    main()


# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('PyCharm')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
